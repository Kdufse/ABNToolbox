rm -rf /data/adb/modules/ABN_Installer
rm -rf /data/adb/modules_update/ABN_Installer