abort_verify() {
  ui_print "*********************************************************"
  ui_print "! $1"
  ui_print "! 这个模块可能没有下载完全，请重新执行此脚本"
  abort    "*********************************************************"
}

extract() {
  file=$1
  customized=$2
  file_path=""
  hash_path=""
  if [ $customized = true ]; then
    file_path="$MODPATH/files/notinstall/$(basename "$file")"
    hash_path="$MODPATH/verify/$(basename "$file").sha256"
  else
    file_path="$MODPATH/files/modules/$(basename "$file")"
    hash_path="$MODPATH/verify/$(basename "$file").sha256"
  fi

  [ -f "$file" ] || abort_verify "$file 不存在"
  [ -f "$hash_path" ] || abort_verify "$hash_path 不存在"

  (echo "$(cat "$hash_path")  $file_path" | sha256sum -c -s -) || abort_verify "校验失败： $file"
  echo "- 校验成功： $file" >&1
}

for file in "$MODPATH"/files/modules/*; do
    if [ -f "$file" ]; then
        extract "$file"
    fi
done

for file in "$MODPATH"/files/notinstall/*; do
    if [ -f "$file" ]; then
        extract "$file" true
    fi
done